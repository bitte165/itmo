# Задание 1
import re
eye = [":", ";", "X", "8", "="]
nose = ["-", "<", "-{", "<{"]
mouth = ["(", ")", "O", "|", "\\", "/", "P"]
myNumber = 338926

def do_the_thing(number):
    face = f"{eye[number%5]}{nose[number%4]}{mouth[number%7]}"
    return f"Исходное число: \t{number}\nГлаза:\t{number%5}\t{eye[number%5]}\nНос:\t{number%4}\t{nose[number%4]}\nРот:\t{number%7}\t{mouth[number%7]}\nЛицо:\t{face}\n"
print("Моё лицо по варианту:\n" + do_the_thing(myNumber))

face = eye[myNumber%5] + nose[myNumber%4] + mouth[myNumber%7]

#Тесты
if face.count(r')') or face.count(r'(') >0:
    faceButWorkable = face.replace(r')', r'\)')
    faceButWorkable = face.replace(r'(',r'\(')

#Тест 1
testText1 = open("testText1.txt","r", encoding = 'utf-8')
testText1Text = testText1.read().splitlines()
testText1Count = 0
for i in range(len(testText1Text)):
    testText1Count += len((re.findall(faceButWorkable, testText1Text[i])))
print("Кол-во лиц", face, "В первом тесте равно:", "\t",testText1Count)
#Тест 2
testText2 = open("testText2.txt","r", encoding = 'utf-8')
testText2Text = testText2.read().splitlines()
testText2Count = 0
for i in range(len(testText2Text)):
    testText2Count += len((re.findall(faceButWorkable, testText2Text[i])))
print("Кол-во лиц", face, "Во втором тесте равно:", "\t",testText2Count)
#Тест 3
testText3 = open("testText3.txt","r", encoding = 'utf-8')
testText3Text = testText3.read().splitlines()
testText3Count = 0
for i in range(len(testText3Text)):
    testText3Count += len((re.findall(faceButWorkable, testText3Text[i])))
print("Кол-во лиц", face, "В третьем тесте равно:", "\t",testText3Count)
#Тест 4
testText4 = open("testText4.txt","r", encoding = 'utf-8')
testText4Text = testText4.read().splitlines()
testText4Count = 0
for i in range(len(testText4Text)):
    testText4Count += len((re.findall(faceButWorkable, testText4Text[i])))
print("Кол-во лиц", face, "В четвёртом тесте равно:", testText4Count)
#Тест 5
testText5 = open("testText5.txt","r", encoding = 'utf-8')
testText5Text = testText5.read().splitlines()
testText5Count = 0
for i in range(len(testText5Text)):
    testText5Count += len((re.findall(faceButWorkable, testText5Text[i])))
print("Кол-во лиц", face, "В пятом тесте равно:", "\t",testText5Count)

# Задание 2

HMSorHM = "([2][0-3]|[0-1]\d)(:[0-5]\d){1,2}"
# Тест 1
testTime1 = open("testTime1.txt","r", encoding = 'utf-8')
testTime1Text = testTime1.read()
testTime1TextResult = re.sub(HMSorHM, '(TBD)', testTime1Text)
print("\nИзменённый текст:", testTime1TextResult)
# Тест 2
testTime2 = open("testTime2.txt","r", encoding = 'utf-8')
testTime2Text = testTime2.read()
testTime2TextResult = re.sub(HMSorHM, '(TBD)', testTime2Text)
print("\nИзменённый текст:", testTime2TextResult)
# Тест 3
testTime3 = open("testTime3.txt","r", encoding = 'utf-8')
testTime3Text = testTime3.read()
testTime3TextResult = re.sub(HMSorHM, '(TBD)', testTime3Text)
print("\nИзменённый текст:", testTime3TextResult)
# Тест 4
testTime4 = open("testTime4.txt","r", encoding = 'utf-8')
testTime4Text = testTime4.read()
testTime4TextResult = re.sub(HMSorHM, '(TBD)', testTime4Text)
print("\nИзменённый текст:", testTime4TextResult)
# Тест 5
testTime5 = open("testTime5.txt","r", encoding = 'utf-8')
testTime5Text = testTime5.read()
testTime5TextResult = re.sub(HMSorHM, '(TBD)', testTime5Text)
print("\nИзменённый текст:", testTime5TextResult)
input()